const form = document.getElementById('callbackForm');
const responseMessage = document.getElementById('responseMessage');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  if(form.website.value !== '') {
    responseMessage.textContent = 'არასწორი ფორმა ❌';
    return;
  }
  const formData = {
    name: form.name.value,
    phone: form.phone.value,
    address: form.address.value,
    model: form.model.value,
    token: grecaptcha.getResponse()
  };
  try {
    const res = await fetch('http://localhost:3000/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    const data = await res.json();
    responseMessage.textContent = data.status === 'success' ? 'თქვენი გამოძახება დადასტურებულია ✅' : 'შეცდომა, სცადეთ ხელახლა ❌';
  } catch (err) {
    responseMessage.textContent = 'სერვერთან პრობლემა ❌';
  }
});
