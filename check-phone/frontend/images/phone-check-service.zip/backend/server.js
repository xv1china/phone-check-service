const express = require('express');
const { google } = require('googleapis');
const bodyParser = require('body-parser');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const fetch = require('node-fetch');

const app = express();
app.use(cors());
app.use(bodyParser.json());
const limiter = rateLimit({ windowMs: 5*60*1000, max: 3, message: { status:'failed', message:'Too many requests' }});
app.use(limiter);

const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];
const auth = new google.auth.GoogleAuth({ keyFile: 'service-account.json', scopes: SCOPES });
const sheets = google.sheets({ version:'v4', auth });
const SPREADSHEET_ID = 'YOUR_SHEET_ID_HERE';

app.post('/submit', async (req, res) => {
  const { name, phone, address, model, token } = req.body;
  const secret = 'YOUR_SECRET_KEY';
  const verificationURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secret}&response=${token}`;
  const captchaRes = await fetch(verificationURL, { method: 'POST' });
  const captchaData = await captchaRes.json();
  if(!captchaData.success) return res.status(400).json({status:'failed', message:'Captcha failed'});
  const row = [Date.now(), name, phone, address, model, 'new', new Date().toISOString()];
  await sheets.spreadsheets.values.append({ spreadsheetId: SPREADSHEET_ID, range:'A:G', valueInputOption:'RAW', resource:{values:[row]} });
  res.json({ status:'success' });
});

app.listen(3000, ()=>console.log('Server running on http://localhost:3000'));
