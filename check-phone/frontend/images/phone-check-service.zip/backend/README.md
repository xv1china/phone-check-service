# Phone Check Service

## Setup Instructions

1. Place your `service-account.json` file inside the backend folder.
2. Replace `YOUR_SHEET_ID_HERE` with your Google Sheet ID.
3. Replace `YOUR_SITE_KEY` and `YOUR_SECRET_KEY` with your reCAPTCHA keys.
4. Install dependencies:
```
npm install express googleapis cors body-parser express-rate-limit node-fetch
```
5. Start server:
```
node backend/server.js
```
6. Open `frontend/index.html` in browser to test.
